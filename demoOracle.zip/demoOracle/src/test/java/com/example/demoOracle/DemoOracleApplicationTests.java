package com.example.demoOracle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOracleApplicationTests {

	@Test
	void contextLoads() {
	}

}
