package com.example.demoOracle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoOracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoOracleApplication.class, args);
	}

}
