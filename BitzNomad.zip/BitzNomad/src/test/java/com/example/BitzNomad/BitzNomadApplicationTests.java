package com.example.BitzNomad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitzNomadApplicationTests {

	@Test
	void contextLoads() {
	}

}
