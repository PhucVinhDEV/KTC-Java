package com.example.WareHouseSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WareHouseSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WareHouseSpringBootApplication.class, args);
	}

}
